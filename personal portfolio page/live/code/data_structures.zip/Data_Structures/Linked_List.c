/* 
 * File:   Link_List.c
 * Author: Adam Chisholm
 * Use: Functions to create and delete nodes in a linked list.
 * Created on 2/10/2016
 */

#include <stdio.h>
#include <stdlib.h>

// Define structure of the node
typedef union data{
	int ival;
	float fval;
	char *sval;
} data;

typedef struct linked_list_node {
	data node_data;
	struct linked_list_node *next;
}linked_list_node;

// Create root node. Root can not be changed otherwise all data in list is lost. 
linked_list_node* create_new_list(int new_data){
    // Create temp node
    linked_list_node *temproot;
    // Create memory to store root node
    temproot = (linked_list_node *) malloc( sizeof(linked_list_node));
    // Set root pointer to NULL
    temproot->next = NULL;
    temproot->node_data.ival = new_data;
    return temproot;
}

// Create new node at end of list
void create_new_node(linked_list_node *root, int new_data){
    // Start next Node at root
    linked_list_node *next_node = root;
    // Move Node to end of list
    if(next_node != 0){
        while(next_node->next != 0){
            next_node = next_node->next;
        }
    }
    // Set last node pointer to new node
    next_node->next = malloc(sizeof(linked_list_node));
    // Move pointer to newly created memory
    next_node = next_node->next;
    // Check if enough memory
    if( next_node == 0){
        printf("Out of Memory!");
    }
    // Set data in new node
    else{
        next_node->next = NULL;
        next_node->node_data.ival = new_data;
    }    
}

// Input linked_list and return height
int find_height(linked_list_node *list){
    linked_list_node *temp = list;
    int count = 0;
    // Move thru list increasing count each loop
    if(temp != 0){
        // Increase count after checking if root is not null
        count++;
        while(temp->next != 0){
            temp = temp->next;
            count++;
        }
    }
    return count;
}

// Delete last added node
void delete_last_node(linked_list_node *list){
    linked_list_node *temp = list;
    linked_list_node *to_delete;
    int count = 0;
    
    if(temp != 0){
        count++;
        while(count < find_height(list) - 1){
            temp = temp->next;
            count++;
        }
        // Set to_delete to last node
        to_delete = temp->next;
        // Set second to last node pointer to null
        temp->next = NULL;
        // Free memory allocated for last node
        free(to_delete);
    }
}

// Delete first node. Returns a pointer to the new root.
linked_list_node * delete_first_node_quick(linked_list_node *list1){
    // Set list to temp var in order to save the ptr to memory to be freed.
    linked_list_node *temp = list1;
    // Move temp up one in list
    temp = temp->next;
    // Free now used node
    free(list1);
    // Return ptr to new root
    return temp;
}

// Delete first node data with out changing the ptr to the root. It is much slower on big lists.
void delete_first_node_slow(linked_list_node *list1){
    // Create var to hold ptr to root of list
    linked_list_node *root = list1;
    // Move thru list
    if(list1 != 0){
        // Move data one node forward
        while(list1->next != 0){
            list1->node_data = list1->next->node_data;
            list1 = list1->next;
        }
    }
    // Delete last node
    delete_last_node(root);
    
}

// Print all items in a list in FIFO order
void print_list_FIFO(linked_list_node *root){
    while(root != NULL){
        printf("%d\n", root->node_data);
        root = root->next;
    }  
}

// Print all items in a list in LIFO order
void print_list_LIFO(linked_list_node *root){
    // Create var to hold ptr to next item to be printed
    linked_list_node *print_next;
    // Create for loop count vars
    int count, loops;
    // For loop used to keep track of number of printed items
    for(count = 0; count < find_height(root); count++){
        print_next = root;
		// For loop used to skip to last unprinted item
        for(loops = 0; loops < find_height(root) - 1 - count; loops++){
            print_next = print_next->next;
        }
        printf("%d\n", print_next->node_data);
    }   
}

 // Test finished list
int main(void){
    // Create node var to be used as root. DO NOT change pointer or all data in list will be lost!
    linked_list_node *list1;
    
    // Create root node
    list1 = create_new_list(4);
    
    // Create new nodes and add to end of list
    create_new_node(list1, 2);
    create_new_node(list1, 6);

    print_list_LIFO(list1);
    
    printf("%d", find_height(list1));
    
    return 0;
}