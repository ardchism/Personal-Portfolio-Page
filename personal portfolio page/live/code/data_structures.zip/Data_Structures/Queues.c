/* 
 * File:   Link_List.c
 * Author: Adam Chisholm
 * Use: Functions to create, delete, and peek nodes in a Queue.
 * Created on 2/10/2016
 */

#include <stdio.h>
#include <stdlib.h>

typedef union data{
	int dataINT;
	float dataFLOAT;
	char *dataSTRING;
}data;

typedef struct queue{
	data node_data;
	struct queue *next;
}queue;

// Input Queue and return height
int find_height(queue *list){
    queue *temp = list;
    int count = 0;
    // Move thru list increasing count each loop
    if(temp != 0){
        // Increase count after checking if root is not null
        count++;
        while(temp->next != 0){
            temp = temp->next;
            count++;
        }
    }
    return count;
}

// Delete last node. Wont delete root.
void delete_last_node(queue *list){
    queue *temp = list;
    queue *to_delete;
    int count = 0;
    
    if(temp != 0){
        count++;
        while(count < find_height(list) - 1){
            temp = temp->next;
            count++;
        }
        // Set to_delete to last node
        to_delete = temp->next;
        // Set second to last node pointer to null
        temp->next = NULL;
        // Free memory allocated for last node
        free(to_delete);
    }
}

// Delete root. Only use when list is no longer needed.
void delete_root(queue *list1){
    if(find_height(list1) != 1){
        printf("This was not the only last item in the queue. Cannot delete this root.\n");
    }
    else
        free(list1);
}

// Create root node. Must assigned return value to a ptr to type queue.
queue* create_int_queue(int new_data){
    // Create temp node
    queue *temproot;
    // Create memory to store root node
    temproot = (queue *) malloc( sizeof(queue));
    // Set root pointer to NULL
    temproot->next = NULL;
    temproot->node_data.dataINT = new_data;
    return temproot;
}
queue* create_float_queue(float new_data){
    // Create temp node
    queue *temproot;
    // Create memory to store root node
    temproot = (queue *) malloc( sizeof(queue));
    // Set root pointer to NULL
    temproot->next = NULL;
    temproot->node_data.dataFLOAT = new_data;
    return temproot;
}
queue* create_string_queue(char *new_data){
    // Create temp node
    queue *temproot;
    // Create memory to store root node
    temproot = (queue *) malloc( sizeof(queue));
    // Set root pointer to NULL
    temproot->next = NULL;
    temproot->node_data.dataSTRING = new_data;
    return temproot;
}

// Create new node at end of list.
void enqueue_int(queue *root, int new_data){
    // Start at root
    queue *next_node = root;
    // Move Node to end of list
    if(next_node != 0){
        while(next_node->next != 0){
            next_node = next_node->next;
        }
    }
    // Set last node pointer to new node
    next_node->next = malloc(sizeof(queue));
    // Move pointer to newly created memory
    next_node = next_node->next;
    // Check if enough memory
    if( next_node == 0){
        printf("Out of Memory!");
    }
    // Set data in new node
    else{
        next_node->next = NULL;
        next_node->node_data.dataINT = new_data;
    }  
}
void enqueue_float(queue *root, float new_data){
    // Start at root
    queue *next_node = root;
    // Move Node to end of list
    if(next_node != 0){
        while(next_node->next != 0){
            next_node = next_node->next;
        }
    }
    // Set last node pointer to new node
    next_node->next = malloc(sizeof(queue));
    // Move pointer to newly created memory
    next_node = next_node->next;
    // Check if enough memory
    if( next_node == 0){
        printf("Out of Memory!");
    }
    // Set data in new node
    else{
        next_node->next = NULL;
        next_node->node_data.dataFLOAT = new_data;
    }  
}
void enqueue_string(queue *root, char *new_data){
    // Start at root
    queue *next_node = root;
    // Move Node to end of list
    if(next_node != 0){
        while(next_node->next != 0){
            next_node = next_node->next;
        }
    }
    // Set last node pointer to new node
    next_node->next = malloc(sizeof(queue));
    // Move pointer to newly created memory
    next_node = next_node->next;
    // Check if enough memory
    if( next_node == 0){
        printf("Out of Memory!");
    }
    // Set data in new node
    else{
        next_node->next = NULL;
        next_node->node_data.dataSTRING = new_data;
    }  
}

// Print and delete next node in FIFO.
void dequeue_int(queue *list1){
    // Create var to hold ptr to root of list
    queue *root = list1;
    printf("%d\n", root->node_data.dataINT);
    // Move thru list
    if(list1 != 0){
        // Move data one node forward
        while(list1->next != 0){
            list1->node_data = list1->next->node_data;
            list1 = list1->next;
        }
    }
    // Delete last node
    if(root->next != NULL){
        delete_last_node(root);
    }
    else{
        delete_root(root);
    }
}
void dequeue_float(queue *list1){
    // Create var to hold ptr to root of list
    queue *root = list1;
    printf("%f\n", root->node_data.dataFLOAT);
    // Move thru list
    if(list1 != 0){
        // Move data one node forward
        while(list1->next != 0){
            list1->node_data = list1->next->node_data;
            list1 = list1->next;
        }
    }
    // Delete last node
    if(root->next != NULL){
        delete_last_node(root);
    }
    else{
        delete_root(root);
    }
}
void dequeue_string(queue *list1){
    // Create var to hold ptr to root of list
    queue *root = list1;
    printf("%s\n", root->node_data.dataSTRING);
    // Move thru list
    if(list1 != 0){
        // Move data one node forward
        while(list1->next != 0){
            list1->node_data = list1->next->node_data;
            list1 = list1->next;
        }
    }
    // Delete last node
    if(root->next != NULL){
        delete_last_node(root);
    }
    else{
        delete_root(root);
    }
}

// Print and delete all.
void dequeue_all_int(queue *list1){
    int count, number_of_nodes;
    number_of_nodes = find_height(list1);
    for(count = 0; count < number_of_nodes; count++){
        dequeue_int(list1);
    }
}
void dequeue_all_float(queue *list1){
    int count, number_of_nodes;
    number_of_nodes = find_height(list1);
    for(count = 0; count < number_of_nodes; count++){
        dequeue_float(list1);
    }
}
void dequeue_all_string(queue *list1){
    int count, number_of_nodes;
    number_of_nodes = find_height(list1);
    for(count = 0; count < number_of_nodes; count++){
        dequeue_string(list1);
    }
}

// Print and delete n number of nodes
void dequeue_n_int(queue *list1, int n){
    int count;
    if(n <= find_height(list1)){
        for(count = 0; count < n; count++){
            dequeue_int(list1);
        }
    }
    else
        printf("There are not %d nodes to dequeue\n", n);
}
void dequeue_n_float(queue *list1, int n){
    int count;
    if(n <= find_height(list1)){
        for(count = 0; count < n; count++){
            dequeue_float(list1);
        }
    }
    else
        printf("There are not %d nodes to dequeue\n", n);
}
void dequeue_n_string(queue *list1, int n){
    int count;
    if(n <= find_height(list1)){
        for(count = 0; count < n; count++){
            dequeue_string(list1);
        }
    }
    else
        printf("There are not %d nodes to dequeue\n", n);
}

// View next data without dequeueing.
void peek_int(queue *root){
    printf("%d\n", root->node_data);
}
void peek_float(queue *root){
    printf("%f\n", root->node_data.dataFLOAT);
}
void peek_string(queue *root){
    printf("%s\n", root->node_data.dataSTRING);
}

// View next n node(s) data without dequeueing.
void peek_n_int(queue *root, int n){
    int count;
    // Check that list has at least n nodes
    if(n <= find_height(root)){
        // Move to next in list n times
        for(count = 0; count < n; count++){
            peek_int(root);
            root = root->next;   
        }
    }
    else
        printf("This list does not have %d nodes\n", n);
}
void peek_n_float(queue *root, int n){
    int count;
    // Check that list has at least n nodes
    if(n <= find_height(root)){
        // Move to next in list n times
        for(count = 0; count < n; count++){
            peek_float(root);
            root = root->next;   
        }
    }
    else
        printf("This list does not have %d nodes\n", n);
}
void peek_n_string(queue *root, int n){
    int count;
    // Check that list has at least n nodes
    if(n <= find_height(root)){
        // Move to next in list n times
        for(count = 0; count < n; count++){
            peek_string(root);
            root = root->next;   
        }
    }
    else
        printf("This list does not have %d nodes\n", n);
}

// View all without dequeueing
void peek_all_int(queue *root){
    peek_int(root);
    while(root->next != NULL){
        root = root->next;
        peek_int(root);
    }
}
void peek_all_float(queue *root){
    peek_float(root);
    while(root->next != NULL){
        root = root->next;
        peek_float(root);
    }
}
void peek_all_string(queue *root){
    peek_string(root);
    while(root->next != NULL){
        root = root->next;
        peek_string(root);
    }
}

// Just used for testing. Not needed for data structure.
int main(void){
    // Create ptr to pointer to root.
    queue *queue1, *queue2, *queue3;
    // Assign pointer to newly created root.
    queue1 = create_int_queue(5);
    queue2 = create_float_queue(.25);
    queue3 = create_string_queue("fort worth");
    
    enqueue_int(queue1, 4);
    enqueue_float(queue2, .75);
    enqueue_float(queue2, .65);
    enqueue_string(queue3, "dallas");
    enqueue_string(queue3, "austin");
    
    peek_all_int(queue1);
    peek_all_float(queue2);
    peek_all_string(queue3);
    
    dequeue_n_int(queue1, 2);
    dequeue_n_float(queue2, 2);
    dequeue_n_string(queue3, 3);
}