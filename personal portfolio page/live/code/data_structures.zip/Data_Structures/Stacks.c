/* 
 * File:   Stacks.c
 * Author: Adam Chisholm
 * Use: Functions to create, delete, and return nodes in a stack(LIFO).
 * Created on 2/10/2016
 */

#include <stdio.h>
#include <stdlib.h>

typedef union data{
	int dataINT;
	float dataFLOAT;
	char *dataSTRING;
}data;

typedef struct stack{
	data node_data;
	struct stack *next;
}stack;

// Input stack and return height
int find_height(stack *root){
    stack *temp = root;
    int count = 0;
    // Move thru list increasing count each loop
    if(temp != 0){
        // Increase count after checking if root is not null
        count++;
        while(temp->next != 0){
            temp = temp->next;
            count++;
        }
    }
    return count;
}

// Delete last node. Wont delete root.
void delete_last_node(stack *root){
    stack *temp = root;
    stack *to_delete;
    int count = 0;
    
    if(temp != 0){
        count++;
        while(count < find_height(root) - 1){
            temp = temp->next;
            count++;
        }
        // Set to_delete to last node
        to_delete = temp->next;
        // Set second to last node pointer to null
        temp->next = NULL;
        // Free memory allocated for last node
        free(to_delete);
    }
}

// Delete root. Only use when list is no longer needed.
void delete_root(stack *root){
    if(find_height(root) != 1){
        printf("This was not the only last item in the stack. Cannot delete this root.\n");
    }
    else
        free(root);
}

// Create root node. Must assigned return value to a ptr to type stack.
stack* create_int_stack(int new_data){
    // Create temp node
    stack *root;
    // Create memory to store root node
    root = (stack *) malloc( sizeof(stack));
    // Set root pointer to NULL
    root->next = NULL;
    root->node_data.dataINT = new_data;
    return root;
}
stack* create_float_stack(float new_data){
    // Create temp node
    stack *root;
    // Create memory to store root node
    root = (stack *) malloc( sizeof(stack));
    // Set root pointer to NULL
    root->next = NULL;
    root->node_data.dataFLOAT = new_data;
    return root;
}
stack* create_string_stack(char *new_data){
    // Create temp node
    stack *root;
    // Create memory to store root node
    root = (stack *) malloc( sizeof(stack));
    // Set root pointer to NULL
    root->next = NULL;
    root->node_data.dataSTRING = new_data;
    return root;
}

// Create new node at end of list.
void push_int(stack *root, int new_data){
    // Start at root
    stack *next_node = root;
    // Move Node to end of root
    if(next_node != 0){
        while(next_node->next != 0){
            next_node = next_node->next;
        }
    }
    // Set last node pointer to new node
    next_node->next = malloc(sizeof(stack));
    // Move pointer to newly created memory
    next_node = next_node->next;
    // Check if enough memory
    if( next_node == 0){
        printf("Out of Memory!");
    }
    // Set data in new node
    else{
        next_node->next = NULL;
        next_node->node_data.dataINT = new_data;
    }  
}
void push_float(stack *root, float new_data){
    // Start at root
    stack *next_node = root;
    // Move Node to end of list
    if(next_node != 0){
        while(next_node->next != 0){
            next_node = next_node->next;
        }
    }
    // Set last node pointer to new node
    next_node->next = malloc(sizeof(stack));
    // Move pointer to newly created memory
    next_node = next_node->next;
    // Check if enough memory
    if( next_node == 0){
        printf("Out of Memory!");
    }
    // Set data in new node
    else{
        next_node->next = NULL;
        next_node->node_data.dataFLOAT = new_data;
    }  
}
void push_string(stack *root, char *new_data){
    // Start at root
    stack *next_node = root;
    // Move Node to end of list
    if(next_node != 0){
        while(next_node->next != 0){
            next_node = next_node->next;
        }
    }
    // Set last node pointer to new node
    next_node->next = malloc(sizeof(stack));
    // Move pointer to newly created memory
    next_node = next_node->next;
    // Check if enough memory
    if( next_node == 0){
        printf("Out of Memory!");
    }
    // Set data in new node
    else{
        next_node->next = NULL;
        next_node->node_data.dataSTRING = new_data;
    }  
}

// Print and delete next in LIFO
void pop_int(stack *root){
    // store root to use for delete_last
    stack *to_delete = root;
    // find last node and print
    while(root->next != NULL){
        root = root->next;
    }
    printf("%d\n", root->node_data);
    // delete last node
    if(find_height(to_delete) == 1){
        delete_root(to_delete);
    }
    else
        delete_last_node(to_delete);
}
void pop_float(stack *root){
    // store root to use for delete_last
    stack *to_delete = root;
    // find last node and print
    while(root->next != NULL){
        root = root->next;
    }
    printf("%f\n", root->node_data.dataFLOAT);
    // delete last node
    if(find_height(to_delete) == 1){
        delete_root(to_delete);
    }
    else
        delete_last_node(to_delete);
}
void pop_string(stack *root){
    // store root to use for delete_last
    stack *to_delete = root;
    // find last node and print
    while(root->next != NULL){
        root = root->next;
    }
    printf("%s\n", root->node_data.dataSTRING);
    // delete last node
    if(find_height(to_delete) == 1){
        delete_root(to_delete);
    }
    else
        delete_last_node(to_delete);
}

// Print and delete all.
void pop_all_int(stack *root){
    int count, number_of_nodes;
    number_of_nodes = find_height(root);
    for(count = 0; count < number_of_nodes; count++){
        pop_int(root);
    }
}
void pop_all_float(stack *root){
    int count, number_of_nodes;
    number_of_nodes = find_height(root);
    for(count = 0; count < number_of_nodes; count++){
        pop_float(root);
    }
}
void pop_all_string(stack *root){
    int count, number_of_nodes;
    number_of_nodes = find_height(root);
    for(count = 0; count < number_of_nodes; count++){
        pop_string(root);
    }
}

// Print and delete n number of nodes
void pop_n_int(stack *root, int n){
    int count;
    if(n <= find_height(root)){
        for(count = 0; count < n; count++){
            pop_int(root);
        }
    }
    else
        printf("There are not %d nodes to pop\n", n);
}
void pop_n_float(stack *root, int n){
    int count;
    if(n <= find_height(root)){
        for(count = 0; count < n; count++){
            pop_float(root);
        }
    }
    else
        printf("There are not %d nodes to pop\n", n);
}
void pop_n_string(stack *root, int n){
    int count;
    if(n <= find_height(root)){
        for(count = 0; count < n; count++){
            pop_string(root);
        }
    }
    else
        printf("There are not %d nodes to pop\n", n);
}

// View next data without stacking.
void peek_int(stack *root){
    while(root->next != NULL){
        root = root->next;
    }
    printf("%d\n", root->node_data);
}
void peek_float(stack *root){
    while(root->next != NULL){
        root = root->next;
    }
    printf("%f\n", root->node_data.dataFLOAT);
}
void peek_string(stack *root){
    while(root->next != NULL){
        root = root->next;
    }
    printf("%s\n", root->node_data.dataSTRING);
}

// View next n node(s) data without popping.
void peek_n_int(stack *root, int n){
    int count, print_count;
    stack *mover = root;
    if(n <= find_height(root)){
        for(print_count = 0; print_count < n; print_count++){    
            mover = root;
            for(count = 1; count < find_height(root) - print_count; count++){
                mover = mover->next;
            }
            printf("%d\n", mover->node_data);
        }
    }
    else
        printf("There are not %d nodes to pop\n", n);
}
void peek_n_float(stack *root, int n){
    int count, print_count;
    stack *mover = root;
    if(n <= find_height(root)){
        for(print_count = 0; print_count < n; print_count++){    
            mover = root;
            for(count = 1; count < find_height(root) - print_count; count++){
                mover = mover->next;
            }
            printf("%f\n", mover->node_data.dataFLOAT);
        }
    }
    else
        printf("There are not %d nodes to pop\n", n);
}
void peek_n_string(stack *root, int n){
    int count, print_count;
    stack *mover = root;
    if(n <= find_height(root)){
        for(print_count = 0; print_count < n; print_count++){    
            mover = root;
            for(count = 1; count < find_height(root) - print_count; count++){
                mover = mover->next;
            }
            printf("%s\n", mover->node_data.dataSTRING);
        }
    }
    else
        printf("There are not %d nodes to pop\n", n);
}

// View all node(s) data without popping.
void peek_all_int(stack *root){
    int count, print_count;
    stack *mover = root;
        for(print_count = 0; print_count < find_height(root); print_count++){    
            mover = root;
            for(count = 1; count < find_height(root) - print_count; count++){
                mover = mover->next;
            }
            printf("%d\n", mover->node_data);
        }
}
void peek_all_float(stack *root){
    int count, print_count;
    stack *mover = root;
        for(print_count = 0; print_count < find_height(root); print_count++){    
            mover = root;
            for(count = 1; count < find_height(root) - print_count; count++){
                mover = mover->next;
            }
            printf("%f\n", mover->node_data.dataFLOAT);
        }
}
void peek_all_string(stack *root){
    int count, print_count;
    stack *mover = root;
        for(print_count = 0; print_count < find_height(root); print_count++){    
            mover = root;
            for(count = 1; count < find_height(root) - print_count; count++){
                mover = mover->next;
            }
            printf("%s\n", mover->node_data.dataSTRING);
        }
}

int main(void){

    stack *stack1, *stack2, *stack3;
    
    stack1 = create_int_stack(2);
    stack2 = create_float_stack(.75);
    stack3 = create_string_stack("Austin");
    
    push_int(stack1, 5);
    push_int(stack1, 6);
    push_float(stack2, .45);
    push_string(stack3, "Dallas");
    
    peek_all_int(stack1);
    peek_all_float(stack2);
    peek_all_string(stack3);
    
    pop_n_int(stack1, 2);
    pop_n_float(stack2, 2);
    pop_n_string(stack3, 2);
 
}