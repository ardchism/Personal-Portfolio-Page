/**
 *
 * Created by: Adam Chisholm
 * Created on: May 1, 2016, 3:11:47 PM
 */

package pythagorean_triplet_euler_9;

import static java.lang.System.in;
import java.util.Scanner;

public class Euler_9 {

    
    public static void main(String[] args) {
		
		System.out.println("Please enter the sum of a+b+c:");
        
        Scanner input = new Scanner(in);
        int sum = input.nextInt();
		
        Pythagorean_Triplet user_triplet = new Pythagorean_Triplet(sum);
        System.out.println("The product of the triplet with a sum of " + user_triplet.user_sum  + " is " + user_triplet.find_user_triplet());
    }

}
