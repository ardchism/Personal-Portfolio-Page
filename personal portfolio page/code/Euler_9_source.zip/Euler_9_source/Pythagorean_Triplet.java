/**
 *
 * Created by: Adam Chisholm
 * Created on: May 1, 2016, 3:12:16 PM
 * Use:
 * This program finds all Pythagorean triplets and checks if sum of a+b+c is equal to n.
 * if there is a match the find_user_triplet function returns the product of a,b,and c.
 */

package pythagorean_triplet_euler_9;


public class Pythagorean_Triplet {
        
        int a, b, c;   // a and b are used to store the sides of the triangle.
        int user_sum;       // user_sum stores the desired sum user is searching
        int r=2, factor1=1, factor2;
        
        Pythagorean_Triplet(int sum){
        
            user_sum = sum;
            
        }
        
        // Dickson method will return all triplets no matter the family
        // states if r is positive and even r^2=2st or r^2/2=s(t)
        // Then x=r+s, y=r+t, z=r+s+t
        private void find_next_triplet_method_1(){
            
            while(true){
                // find factors of next r^2/2 and plug into equation for s & t
                if( (r*r)/2 % factor1 == 0){
                factor2 = ((r*r)/2) / factor1;
                a = r + factor1;
                b = r + factor2;
                c = r + factor1 + factor2;
                factor1++;
                break;
                }
                // if factor1 is greater than r^2/2, move to next r and set factor as 1
                else if(factor1 == ((r*r)/2) + 1){
                    r += 2;
                    factor1 = 1;
                }
                else
                    factor1++;
            } 
        }

        // used to find if any triplets sum match user sum.
        // return product if any match or alert user if no match
        public int find_user_triplet(){
        
            int product = 0; // store product if match
            
            while(a+b+c < 1000000){
            
                find_next_triplet_method_1();
                // if sums are equal find product
                if(a+b+c == user_sum){
                    product = a*b*c;
                    break;
                }    
            }

            
            if(product == 0){
                System.out.println("No Match Was Found");
            }
            
            return product;
        }
        
}
