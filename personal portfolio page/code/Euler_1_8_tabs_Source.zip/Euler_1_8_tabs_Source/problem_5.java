package Euler_1_8_tabs;

public class problem_5 {
    
    long multipleNumber = 0;
    
    public problem_5(long multNumber){
    
        multipleNumber = multNumber;
        
    }
    
    public long final_test(){
    
        long finalNumber = 1;
                
        for(int count = 1; count <= multipleNumber; count++){
            if(finalNumber % count != 0){
                finalNumber++;
                count = 0;
            }
        }
        
        return finalNumber;   
    }  
}
