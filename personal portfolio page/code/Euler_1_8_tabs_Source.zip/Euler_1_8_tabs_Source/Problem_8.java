/**
 *
 * Created by: Adam Chisholm
 * Created on: Apr 19, 2016, 1:57:02 PM
 */

package Euler_1_8_tabs;


public class Problem_8 {

    int adjacent_digits;
    long max_product = 1;
    String user_string;
    
    public Problem_8(int digit, String new_str){
    
        adjacent_digits = digit;
        user_string = new_str;
    
    }
    
    public long find_max_product(){
        
        long new_product = 1;
        
        for(int series_count = 0; series_count + adjacent_digits < user_string.length(); series_count++){
            
            // find next product
            for(int count = 0; count <= adjacent_digits; count++){
        
                new_product *= (user_string.charAt(count + series_count) - '0');
            }
        
            // test to find which is max
            if(new_product > max_product){
            
                max_product = new_product;
            }
            
            // Set new_product back to 1
            new_product = 1;
        }
        
        return max_product;
    }
    
}
