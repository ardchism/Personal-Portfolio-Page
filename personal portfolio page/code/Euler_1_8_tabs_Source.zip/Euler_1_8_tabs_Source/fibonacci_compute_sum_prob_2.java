package Euler_1_8_tabs;

public class fibonacci_compute_sum_prob_2 {
   
    long a = 1, b = 1, c = a + b, sum = 0, max;
    
    public fibonacci_compute_sum_prob_2(long user_max){
    
        max = user_max;
        
    }
    
    public long compute(){
        // loop while c is less then equal to user gen max
        while(c < max){
            // check if c is even and if it is add to sum
            if((c%2 == 0)){
                sum += c;
            }
            // find next fib number
            a = b;
            b = c;
            c = (a + b);
        }     
       return sum;
    }
}
