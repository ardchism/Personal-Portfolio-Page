/**
 *
 * Created by: Adam Chisholm
 * Created on: Apr 29, 2016, 11:49:10 AM
 */

package Euler_1_8_tabs;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class final_tabs implements ActionListener{
    // Global elements to be used in JPanel
    JTextField jtfproblem_1_1, jtfproblem_1_2;
    JLabel problem1_result;
    JButton jbtnproblem_1_1;
    
    JTextField jtfproblem_2_1;
    JLabel problem2_result;
    JButton jbtnproblem_2_1;
    
    JTextField jtfproblem_3_1;
    JLabel problem3_result;
    JButton jbtnproblem_3_1;
    
    JTextField jtfproblem_4_1;
    JLabel problem4_result;
    JButton jbtnproblem_4_1;
    
    JTextField jtfproblem_5_1;
    JLabel problem5_result;
    JButton jbtnproblem_5_1;
    
    JTextField jtfproblem_6_1;
    JLabel problem6_result;
    JButton jbtnproblem_6_1;
    
    JTextField jtfproblem_7_1;
    JLabel problem7_result;
    JButton jbtnproblem_7_1;
    
    JTextField jtfproblem_8_1;
    JTextArea jtaproblem_8_1;
    JLabel problem8_result;
    JButton jbtnproblem_8_1;
    
    final_tabs() {
    
        // Create jframe deafualt border, give initial size, set term on exit.
        JFrame jfrm = new JFrame("Project Euler Problems 1-8");
        jfrm.setSize(400, 250);
        jfrm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // Create items for prob 1, add action commands, and add to panel 11
        JLabel problem1_main_title = new JLabel("Find sum of multiples < 1000 of two integers < 100 ");
        JLabel jlabproblem_1_1 = new JLabel("Please enter a number <100");
        JLabel jlabproblem_1_2 = new JLabel("Please enter a number <100");
        problem1_result = new JLabel(" ");
        jtfproblem_1_1 = new JTextField(10);
        jtfproblem_1_2 = new JTextField(10);
        jbtnproblem_1_1 = new JButton("Find Sum problem 1");
        JPanel jpn11 = new JPanel();
        jpn11.setLayout(new FlowLayout());
        jpn11.setOpaque(true);
        jtfproblem_1_1.setActionCommand("Find Sum problem 1");
        jtfproblem_1_2.setActionCommand("Find Sum problem 1");
        jtfproblem_1_1.addActionListener((ActionListener) this);
        jtfproblem_1_2.addActionListener((ActionListener) this);
        jbtnproblem_1_1.addActionListener((ActionListener) this);
        jpn11.add(problem1_main_title);
        jpn11.add(jlabproblem_1_1);
        jpn11.add(jtfproblem_1_1);
        jpn11.add(jlabproblem_1_2);
        jpn11.add(jtfproblem_1_2);
        jpn11.add(jbtnproblem_1_1);
        jpn11.add(problem1_result);
 
        // Create items for prob 2, add action commands, and add to panel 12
        JLabel problem_2_main_title = new JLabel("Find sum of even fibonacci numbers less than input");
        JLabel jlabproblem_2_1= new JLabel("Please enter a number <= 4,000,000");
        problem2_result = new JLabel(" ");
        jtfproblem_2_1 = new JTextField(10);
        jbtnproblem_2_1 = new JButton("Find Sum problem 2");
        JPanel jpn12 = new JPanel();
        jpn12.setLayout(new FlowLayout());
        jpn12.setOpaque(true);
        jtfproblem_2_1.setActionCommand("Find Sum problem 2");
        jtfproblem_2_1.addActionListener((ActionListener) this);
        jbtnproblem_2_1.addActionListener((ActionListener) this);
        jpn12.add(problem_2_main_title);
        jpn12.add(jlabproblem_2_1);
        jpn12.add(jtfproblem_2_1);
        jpn12.add(jbtnproblem_2_1);
        jpn12.add(problem2_result);
        
        // Create items for prob 3, add action commands, and add to panel 13
        JLabel problem_3_main_title = new JLabel("Find the largest prime factor of input number");
        JLabel jlabproblem_3_1 = new JLabel("Please enter a number <= 1,000,000,000,000,000");
        problem3_result = new JLabel(" ");
        jtfproblem_3_1 = new JTextField(10);
        jbtnproblem_3_1 = new JButton("Find Factor problem 3");
        JPanel jpn13 = new JPanel();
        jpn13.setLayout(new FlowLayout());
        jpn13.setOpaque(true);
        jtfproblem_3_1.setActionCommand("Find Factor problem 3");
        jtfproblem_3_1.addActionListener((ActionListener) this);
        jbtnproblem_3_1.addActionListener((ActionListener) this);
        jpn13.add(problem_3_main_title);
        jpn13.add(jlabproblem_3_1);
        jpn13.add(jtfproblem_3_1);
        jpn13.add(jbtnproblem_3_1);
        jpn13.add(problem3_result);
        
        // Create items for prob 4, add action commands, and add to panel 14
        JLabel problem_4_main_title = new JLabel("Find the largest palindrome product of");
        JLabel problem_4_main_title_2 = new JLabel("any two numbers less then the limit");
        JLabel jlabproblem_4_1 = new JLabel("Please enter a number <= 10,000");
        problem4_result = new JLabel(" ");
        jtfproblem_4_1 = new JTextField(10);
        jbtnproblem_4_1 = new JButton("Find largest palindrome problem 4");
        JPanel jpn14 = new JPanel();
        jpn14.setLayout(new FlowLayout());
        jpn14.setOpaque(true);
        jtfproblem_4_1.setActionCommand("Find largest palindrome problem 4");
        jtfproblem_4_1.addActionListener((ActionListener) this);
        jbtnproblem_4_1.addActionListener((ActionListener) this);
        jpn14.add(problem_4_main_title);
        jpn14.add(problem_4_main_title_2);
        jpn14.add(jlabproblem_4_1);
        jpn14.add(jtfproblem_4_1);
        jpn14.add(jbtnproblem_4_1);
        jpn14.add(problem4_result);
        
        // Create items for prob 5, add action commands, and add to panel 15
        JLabel problem_5_main_title = new JLabel("Find the smallest number which can be divided");
        JLabel problem_5_main_title2 = new JLabel("by each number 1-n with no remainder");
        JLabel jlabproblem_5_1 = new JLabel("Please enter a number <= 20");
        problem5_result = new JLabel(" ");
        jtfproblem_5_1 = new JTextField(10);
        jbtnproblem_5_1 = new JButton("Find smallest mult problem 5");
        JPanel jpn15 = new JPanel();
        jpn15.setLayout(new FlowLayout());
        jpn15.setOpaque(true);
        jtfproblem_5_1.setActionCommand("Find smallest mult problem 5");
        jtfproblem_5_1.addActionListener((ActionListener) this);
        jbtnproblem_5_1.addActionListener((ActionListener) this);
        jpn15.add(problem_5_main_title);
        jpn15.add(problem_5_main_title2);
        jpn15.add(jlabproblem_5_1);
        jpn15.add(jtfproblem_5_1);
        jpn15.add(jbtnproblem_5_1);
        jpn15.add(problem5_result);
        
        // Create items for prob 6, add action commands, and add to panel 16
        JLabel problem_6_main_title = new JLabel("Find the difference between the sum of squares and");
        JLabel problem_6_main_title2 = new JLabel("the square of sums of all natural numbers to the limit");
        JLabel jlabproblem_6_1 = new JLabel("Please enter a number <= 100");
        problem6_result = new JLabel(" ");
        jtfproblem_6_1 = new JTextField(10);
        jbtnproblem_6_1 = new JButton("Find square sum problem 6");
        JPanel jpn16 = new JPanel();
        jpn16.setLayout(new FlowLayout());
        jpn16.setOpaque(true);
        jtfproblem_6_1.setActionCommand("Find square sum problem 6");
        jtfproblem_6_1.addActionListener((ActionListener) this);
        jbtnproblem_6_1.addActionListener((ActionListener) this);
        jpn16.add(problem_6_main_title);
        jpn16.add(problem_6_main_title2);
        jpn16.add(jlabproblem_6_1);
        jpn16.add(jtfproblem_6_1);
        jpn16.add(jbtnproblem_6_1);
        jpn16.add(problem6_result);
        
        // Create items for prob 7, add action commands, and add to panel 17
        JLabel problem_7_main_title = new JLabel("Find the nth prime, where n is provided by the user");
        JLabel jlabproblem_7_1 = new JLabel("Please enter a number <= 15000");
        problem7_result = new JLabel(" ");
        jtfproblem_7_1 = new JTextField(10);
        jbtnproblem_7_1 = new JButton("Find Prime problem 7");
        JPanel jpn17 = new JPanel();
        jpn17.setLayout(new FlowLayout());
        jpn17.setOpaque(true);
        jtfproblem_7_1.setActionCommand("Find Prime problem 7");
        jtfproblem_7_1.addActionListener((ActionListener) this);
        jbtnproblem_7_1.addActionListener((ActionListener) this);
        jpn17.add(problem_7_main_title);
        jpn17.add(jlabproblem_7_1);
        jpn17.add(jtfproblem_7_1);
        jpn17.add(jbtnproblem_7_1);
        jpn17.add(problem7_result);
        
        // Create items for prob 8, add action commands, and add to panel 18
        JLabel problem_8_main_title = new JLabel("Find the nth prime, where n is provided by the user");
        JLabel jlabproblem_8_1 = new JLabel("Please enter a number <= 15");
        JLabel jlabproblem_8_2 = new JLabel("Please enter a series up to 1000 digits: ");
        problem8_result = new JLabel(" ");
        jtfproblem_8_1 = new JTextField(10);
        // make scroll text area for long strings
        jtaproblem_8_1 = new JTextArea();
        jtaproblem_8_1.setLineWrap(true);
        jtaproblem_8_1.setWrapStyleWord(true);
        JScrollPane jscrlp_81 = new JScrollPane(jtaproblem_8_1);
        jscrlp_81.setPreferredSize(new Dimension(100, 75));
        jbtnproblem_8_1 = new JButton("Find Product problem 8");
        JPanel jpn18 = new JPanel();
        jpn18.setLayout(new FlowLayout());
        jpn18.setOpaque(true);
        jtfproblem_8_1.setActionCommand("Find Product problem 8");
        jtfproblem_8_1.addActionListener((ActionListener) this);
        jbtnproblem_8_1.addActionListener((ActionListener) this);
        jpn18.add(problem_8_main_title);
        jpn18.add(jlabproblem_8_1);
        jpn18.add(jtfproblem_8_1);
        jpn18.add(jlabproblem_8_2);
        jpn18.add(jscrlp_81);
        jpn18.add(jbtnproblem_8_1);
        jpn18.add(problem8_result);
        
        // Create a tabbed pane with a scroll policy, add panels to tabs, and display the frame
        JTabbedPane jtp = new JTabbedPane(JTabbedPane.TOP, JTabbedPane.SCROLL_TAB_LAYOUT);
        jtp.addTab("Problem 1", jpn11);
        jtp.addTab("Problem 2", jpn12);
        jtp.addTab("Problem 3", jpn13);
        jtp.addTab("Problem 4", jpn14);
        jtp.addTab("Problem 5", jpn15);
        jtp.addTab("Problem 6", jpn16);
        jtp.addTab("Problem 7", jpn17);
        jtp.addTab("Problem 8", jpn18);
        jfrm.add(jtp);
        jfrm.setVisible(true);
    }
    
    // check if string is numeric
    public boolean isLong( String input ) {
        try {
            Long.parseLong(input );
            return true;
        } catch( Exception e) {
            return false;
        }
    }
    
    // Check if string is numeric
    public boolean isInt( String input ) {
        try {
            Integer.parseInt(input );
            return true;
        } catch( Exception e) {
            return false;
        }
    }
    
    // find if string is all between 0-9
    public boolean isNum(String input){
        boolean result1 = false;
        for(int count = 0; count < input.length(); count++){
            if(input.charAt(count) >= '0' && input.charAt(count) <= '9'){
                result1 = true;
            }
            else{
                result1 = false;
                break;
            }
        }
        return result1;  
    }
    
    // Handle action event
    @Override
    public void actionPerformed(ActionEvent ae){
        
        // Problem 1 events handled
        if(ae.getActionCommand().equals("Find Sum problem 1")){
            String text11 = jtfproblem_1_1.getText();
            String text12 = jtfproblem_1_2.getText();
            int number11 = Integer.parseInt(text11);
            int number12 = Integer.parseInt(text12);
            if( number11 <= 100 && number12 <= 100){
                int sum_1 = 0;
                // logic for i < 1000 
                for (int i = 0; i < 1000; i++){
                    // find sum of mults of first number less than 1000
                    if((number11 * i) < 1000){
                        sum_1 += (number11 * i);
                    }
                    // at mults less then 1000 of number 2 to the sum if number is not also a mult of number 1
                    if((number12 * i) < 1000 && (number12 * i) % number11 != 0){
                        sum_1 += (number12 * i);
                    }    
                }
                // Print sum to result label
                problem1_result.setText("The sum is " + sum_1);
            }
            else{
        
                problem1_result.setText("Please enter a numbers less then 100");   
            }
        }
        
        // Problem 2 events handled
        if(ae.getActionCommand().equals("Find Sum problem 2")){
            String text21 = jtfproblem_2_1.getText();
            long number21 = Integer.parseInt(text21);
            if( number21 <= 4000000){
                fibonacci_compute_sum_prob_2 program_sum_prob_2 = new fibonacci_compute_sum_prob_2(number21);
                // Print sum to result label
                problem2_result.setText("The sum is " + program_sum_prob_2.compute());
                }
            else{
        
                problem2_result.setText("Please enter a number less then or equal to 4,000,000");   
            }
        }
        
        // Problem 3 events handled
        if(ae.getActionCommand().equals("Find Factor problem 3")){
            String text31 = jtfproblem_3_1.getText();
            long number31;
            // check string is numeric
            if(isLong(text31) == true){
                number31 = Long.parseLong(text31); 
            }
            else{
                number31 = 0;
            }
            // check number is within limit and not 0.
            if( number31 <= 1000000000000000L && number31 != 0){
                return_prime_factors_prob_3 user_factor = new return_prime_factors_prob_3(number31);
                // Print sum to result label
                problem3_result.setText("The largest prime factor is " + user_factor.find_factors());
                }
            else{
        
                problem3_result.setText("Please enter a number less then or equal to 1,000,000,000,000,000");   
            }
        }
        
        // Problem 4 events handled
        if(ae.getActionCommand().equals("Find largest palindrome problem 4")){
            String text41 = jtfproblem_4_1.getText();
            int number41;
            
            // check string is numeric
            if(isInt(text41) == true){
                number41 = Integer.parseInt(text41); 
            }
            else{
                number41 = 0;
            } 
            
            // check number is within limit and not 0.
            if( number41 <= 10000 && number41 != 0){
                Problem_4 user_palindrome = new Problem_4(number41);
                // Print sum to result label
                problem4_result.setText("The largest palindrome product is " + user_palindrome.problem4());
                }
            else{
        
                problem4_result.setText("Please enter a number less then or equal to 10,000");   
            }
        }
        
        // Problem 5 events handled
        if(ae.getActionCommand().equals("Find smallest mult problem 5")){
            String text51 = jtfproblem_5_1.getText();
            int number51;
            
            // check string is numeric
            if(isInt(text51) == true){
                number51 = Integer.parseInt(text51); 
            }
            else{
                number51 = 0;
            } 
            
            // check number is within limit and not 0.
            if( number51 <= 20 && number51 != 0){
                problem_5 user_mult = new problem_5(number51);
                // Print sum to result label
                problem5_result.setText("The smallest multiple of the range is " + user_mult.final_test());
                }
            else{
        
                problem5_result.setText("Please enter a number less then or equal to 20");   
            }
        }
        
        // Problem 6 events handled
        if(ae.getActionCommand().equals("Find square sum problem 6")){
            String text61 = jtfproblem_6_1.getText();
            int number61;
            
            // check string is numeric
            if(isInt(text61) == true){
                number61 = Integer.parseInt(text61); 
            }
            else{
                number61 = 0;
            } 
            
            // check number is within limit and not 0.
            if( number61 <= 100 && number61 != 0){
                Problem_6 problem_6_sum = new Problem_6(number61);
                // Print sum to result label
                problem6_result.setText("The difference is " + problem_6_sum.test_1());
                }
            else{
        
                problem6_result.setText("Please enter a number less then or equal to 100");   
            }
        }
        
        // Problem 7 events handled
        if(ae.getActionCommand().equals("Find Prime problem 7")){
            String text71 = jtfproblem_7_1.getText();
            int number71;
            
            // check string is numeric
            if(isInt(text71) == true){
                number71 = Integer.parseInt(text71); 
            }
            else{
                number71 = 0;
            } 
            
            // check number is within limit and not 0.
            if( number71 <= 15000 && number71 != 0){
                Problem_7 user_prime = new Problem_7(number71);
                // Print sum to result label
                problem7_result.setText("The " + number71 + "th prime is " + user_prime.findPrimeNumber());
                }
            else{
        
                problem7_result.setText("Please enter a number less then or equal to 15,000");   
            }
        }
        
        // Problem 8 events handled
        if(ae.getActionCommand().equals("Find Product problem 8")){
            String text81 = jtfproblem_8_1.getText();
            int number81;
            
            // check string is numeric
            if(isInt(text81) == true){
                number81 = Integer.parseInt(text81); 
            }
            else{
                number81 = 0;
            } 
            
            // check series is numeric
            if(isNum(jtaproblem_8_1.getText()) == true)
                text81 = jtaproblem_8_1.getText();
            else
                text81 = "no";
            
            // check number is within limit and not 0.
            if( number81 <= 15 && number81 != 0 && !"no".equals(text81) && text81.length() > number81){
                Problem_8 user_series = new Problem_8(number81, text81);
                // Print sum to result label
                problem8_result.setText("The product is " + user_series.find_max_product());
                }
            else{
        
                problem8_result.setText("Please enter a number <= to 15 and a numeric series");   
            }
        }    
        
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            final_tabs final_tabs = new final_tabs();
        });
    }

}
