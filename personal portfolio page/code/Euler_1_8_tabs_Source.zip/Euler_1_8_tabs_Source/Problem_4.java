package Euler_1_8_tabs;

public class Problem_4 {
    
    int current_limit;
    
    public Problem_4(int limit){
    
        current_limit = limit;
    
    }
    
    public static boolean isPalindrome(Integer x) {
        String forward = x.toString();
        String backward = new StringBuilder(forward).reverse().toString();
        return forward.equals(backward);
    }
    
    public int problem4(){
        
        int number1 = 0;
        int number2 = 0;
        int palnumber;
        int finishednumber = 0;
        
        while(number1 < current_limit){
            while(number2 < current_limit){
                palnumber = number1 * number2;
                if (isPalindrome(palnumber) && palnumber > finishednumber){
                    finishednumber = palnumber;
                }  
                    number2++; 
            }
            number2 = 0;
            number1++;
        } 
        
       return finishednumber;
    }
}


