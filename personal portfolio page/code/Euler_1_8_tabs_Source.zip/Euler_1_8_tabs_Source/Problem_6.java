package Euler_1_8_tabs;


public class Problem_6 {
    
    int user_number = 0;
    
    public Problem_6(int x){
    
        user_number = x;
        
    }
    
    public double test_1(){
        return squareOfSum(user_number) - sumOfSquares(user_number);
    }
    
    private double sumOfSquares(int x){
        
        double sumOfSquare = 0;
        
        for(int count = 1; count <= x; count++){
            sumOfSquare += Math.pow(count, 2);
        }
        
        return sumOfSquare;
    }
    
    private double squareOfSum(int x){
        
        double squareOfSum, sum = 0;
        
        for(int count = 1; count <= x; count++){
            sum += count;
        }
        
        squareOfSum = Math.pow(sum, 2);
        
        return squareOfSum;
    }
}
