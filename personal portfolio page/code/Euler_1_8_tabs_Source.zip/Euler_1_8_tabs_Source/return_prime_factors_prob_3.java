
package Euler_1_8_tabs;


public class return_prime_factors_prob_3 {
    
    long number;
    
    // Construct with Long number. Must add L to end of int.
    public return_prime_factors_prob_3(long user_number){
    
        number = user_number;
    
    }
    
    public long find_factors(){
        long max_factor = 1L;
        boolean is_prime = false;
        
        // Find next factor greater than 2 because 2 is never prime.
        // Highest factor can only be <= sqrt of number.
        for(long factor = 3L; factor <= Math.sqrt(number); factor++){
            if(number % factor == 0L){
            
                // Determine if factor is prime
                for(long prime_test = 2L; prime_test < factor; prime_test++){
                    is_prime = factor % prime_test != 0L;
                    if(is_prime == false){
                        break;
                    }
                }
                
                // Compare to last prime factor to find greatest
                if(is_prime == true && factor > max_factor){
                    max_factor = factor;
                }
            }
            is_prime = false;
        }
        
        // Determine if number is prime
            for(long prime_test2 = 2L; prime_test2 <= number; prime_test2++){
                is_prime = number % prime_test2 != 0L;
                if(is_prime == false && number == prime_test2){
                    max_factor = number;
                }
                else if(is_prime == false){
                    break;
                }
            }
        
        return max_factor;
    }
}
