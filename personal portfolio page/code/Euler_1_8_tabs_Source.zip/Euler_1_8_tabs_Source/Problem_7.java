package Euler_1_8_tabs;

public class Problem_7 {
    
    int user_prime = 0;
    
    public Problem_7(int x){
     
        user_prime = x;
        
    }    
    
    public long findPrimeNumber(){
        
        long [] primes = new long[user_prime];
        long number = 2;
        long test;
        int count = 1;
        primes[0] = 2;
        
        while( count < user_prime ){ //count to user number
            number++;
            test = 2;
            while ( (number % test != 0) && (test < number) ){ //find next prime
                if(test == (number - 1)){   //test if number was prime
                    primes[count] = number; //set new prime and increase count & number
                    count++;                   
                }
                test++;
            }
        }
        return primes[user_prime-1];
    }
    
}
