/**
 *
 * Created by: Adam Chisholm
 * Created on: May 2, 2016, 11:06:03 AM
 */

import static java.lang.System.in;
import java.util.Scanner;

public class SumOfPrimes_main {

    
    public static void main(String[] args) {
        
        System.out.println("Please enter a number to find the sum of all primes less then it:");
        
        Scanner input = new Scanner(in);
        int limit = input.nextInt();
        
        SumOfPrimes_object user_sum = new SumOfPrimes_object(limit);
        long sum = user_sum.find_sum_of_primes();
        System.out.println("The sum of all primes < " + limit + " is " + sum);
    }

}
