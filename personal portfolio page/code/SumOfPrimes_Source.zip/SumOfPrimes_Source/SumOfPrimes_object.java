/**
 *
 * Created by: Adam Chisholm
 * Created on: May 2, 2016, 11:07:16 AM
 * Use: This class creates an object, which stores the Summation of all prime numbers < n.
 * n will be a field provided by the user. the Sieve of Eratosthenes is created in this program.
 */




public class SumOfPrimes_object {
        //Gloabal field sum used to store running total of sums, and the limit.
        long sum=0;
        int limit;
        
        // User passes a limit when object is created, which gets stored in global limit.
        public SumOfPrimes_object(int user_limit){
        
            limit = user_limit;
        }
        
        public long find_sum_of_primes(){
            
            // create array of booleans for sieve and set n=0 & n=1 to 0
            boolean sieve[] = new boolean[limit];  
            sieve[0] = false;
            sieve[1] = false;
            
            // Set all values greater then 1 to true
            for(int true_count = 2; true_count < limit; true_count++){
                sieve[true_count] = true;
            }
            
            // Use sieve of Eratosthenes to find all not primes and set false
            for(int i = 2; i < Math.sqrt(limit); i++){
                if(sieve[i] == true){
                    for(int j = (i * i); j < limit; j = j+i){
                        sieve[j] = false; 
                    }    
                }
            }
            
            // Add all primes to sum
            for(int sum_count = 0; sum_count < limit; sum_count++){
                if(sieve[sum_count] == true){
                    sum += sum_count;
                }
            }
            
            
            return sum;
        
        }
}
