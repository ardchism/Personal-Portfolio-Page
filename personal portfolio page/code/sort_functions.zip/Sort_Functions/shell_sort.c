/* 
 * File:  shell_sort.c
 * Author: Adam Chisholm
 * Use: Sort array of ints using an shell sort algorithm.
 * Created on 2/23/2016
 */

#include <stdio.h>
#include <stdlib.h>

// First parm is an int array, while the second is the number of ints in the array
void shell_sort_min(int numbers[], int n){
    int i, j, increment, temp, print_count;
    // first for loop set increment to half of list. Then divide by 2 each loop
    for(increment = n/2; increment > 0; increment /= 2){
        // store value at index i in a temp var
        for(i = increment; i < n; i++){
            temp = numbers[i];
            // check temp vs j value - increment while j >= increment and replace if needed else break current loop
            for(j = i; j >= increment; j-=increment){
                if(temp < numbers[j-increment]){
                    numbers[j] = numbers[j-increment];
                }
                else{
                    break;
                }
            }
            numbers[j] = temp;
            // print array at end of each loop to check insertion is working in correct order.
            for(print_count = 0; print_count < n; print_count++){
                printf("%d ", numbers[print_count]);
            }
            printf("\n");
        }
    }
}
// Parms are the same. This function just returns list in biggest to smallest order.
void shell_sort_max(int numbers[], int n){
    int i, j, increment, temp, print_count;
    // first for loop set increment to half of list. Then divide by 2 each loop
    for(increment = n/2; increment > 0; increment /= 2){
        // store value at index i in a temp var
        for(i = increment; i < n; i++){
            temp = numbers[i];
            // check temp vs j value - increment while j >= increment and replace if needed else break current loop
            for(j = i; j >= increment; j-=increment){
                if(temp > numbers[j-increment]){
                    numbers[j] = numbers[j-increment];
                }
                else{
                    break;
                }
            }
            numbers[j] = temp;
            // print array at end of each loop to check how shell is working.
            for(print_count = 0; print_count < n; print_count++){
                printf("%d ", numbers[print_count]);
            }
            printf("\n");
        }
    }
}
