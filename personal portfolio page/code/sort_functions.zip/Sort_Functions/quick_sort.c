/* 
 * File:  quick_sort.c
 * Author: Adam Chisholm
 * Use: Sort array of ints using a quick sort algorithm.
 * Created on 2/23/2016
 */

#include <stdio.h>
#include <stdlib.h>

// First parm is an int array, while the second is the index to start the sort. The third parm is the ending index.
void quick_sort_min(int numbers[], int start, int finish){
    // check start is less than finish
    if(start >= finish){
        return;
    }
    else{
        // set pivot to start of list
        int pivot = numbers[start];
        int a = start, b, temp, print_count;
        // sort all or right side of i
        for(b = start + 1; b <= finish; b++){
            // move if then pivot
            if(numbers[b] < pivot){
                a = a + 1;
                temp = numbers[a];
                numbers[a] = numbers[b];
                numbers[b] = temp;
            }
        }
        // move pivot to middle of array
        temp = numbers[a];
        numbers[a] = numbers[start];
        numbers[start] = temp;
        // use recursion to sort both sub arrays split at the pivot
        quick_sort_min(numbers, start, a-1);
        quick_sort_min(numbers, a+1, finish);
    }
}
// Parms are the same. This function just returns list in biggest to smallest order.
void quick_sort_max(int numbers[], int start, int finish){
    // check start is less than finish
    if(start >= finish){
        return;
    }
    else{
        // set pivot to start of list
        int pivot = numbers[start];
        int a = start, b, temp, print_count;
        // sort all or right side of i
        for(b = start + 1; b <= finish; b++){
            // move if then pivot
            if(numbers[b] > pivot){
                a = a + 1;
                temp = numbers[a];
                numbers[a] = numbers[b];
                numbers[b] = temp;
            }
        }
        // move pivot to middle of array
        temp = numbers[a];
        numbers[a] = numbers[start];
        numbers[start] = temp;
        // use recursion to sort both sub arrays split at the pivot
        quick_sort_max(numbers, start, a-1);
        quick_sort_max(numbers, a+1, finish);
    }
}
