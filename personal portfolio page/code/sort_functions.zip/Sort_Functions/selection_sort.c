/* 
 * File:   selection_sort.c
 * Author: Adam Chisholm
 * Use: Sort array of ints using a selection sort.
 * Created on 2/23/2016
 */

#include <stdio.h>
#include <stdlib.h>

// First parm is an int array, while the second is the number of ints in the array
void selection_sort_min(int numbers[], int n){
    int loop_count, array_count, index_min;
    // for loop used to cycle thru list n times
    for(loop_count = 0; loop_count < n; loop_count++){
        index_min = loop_count;
        // another loop used to cycle thru array
        for(array_count = loop_count; array_count < n; array_count++){
            if(numbers[index_min] > numbers[array_count]){
                index_min = array_count;
            }
        }
        // save old min
        int temp = numbers[loop_count];
        // store new min in next index
        numbers[loop_count] = numbers[index_min];
        // set new min index to next number in array
        numbers[index_min] = temp;
    }
   
}
// Parms are the same. This function just returns list in biggest to smallest order.
void selection_sort_max(int numbers[], int n){
    int loop_count, array_count, index_min;
    // for loop used to cycle thru list n times
    for(loop_count = 0; loop_count < n; loop_count++){
        index_min = loop_count;
        // another loop used to cycle thru array
        for(array_count = loop_count; array_count < n; array_count++){
            if(numbers[index_min] < numbers[array_count]){
                index_min = array_count;
            }
        }
        // save old min
        int temp = numbers[loop_count];
        // store new min in next index
        numbers[loop_count] = numbers[index_min];
        // set new min index to next number in array
        numbers[index_min] = temp;
    }
   
}
