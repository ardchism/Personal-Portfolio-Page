/* 
 * File:   insertion_sort.c
 * Author: Adam Chisholm
 * Use: Sort array of ints using an insertion sort.
 * Created on 2/23/2016
 */

#include <stdio.h>
#include <stdlib.h>

// First parm is an int array, while the second is the number of ints in the array
void insertion_sort_min(int numbers[], int n){
    int loop_count, array_count, move_count, index, print_count;
    // for loop used to cycle thru list n times
    for(loop_count = 0; loop_count < n - 1; loop_count++){
        index = loop_count + 1;
        // bubble sorts thru array until index is reached 
        while(index > 0 && numbers[index] < numbers[index - 1]){
            int temp = numbers[index];
            numbers[index] = numbers[index - 1];
            numbers[index - 1] = temp;
            index--;
        }
        // print array at end of each loop to check insertion is working in correct order.
        for(print_count = 0; print_count < n; print_count++){
            printf("%d ", numbers[print_count]);
        }
        printf("\n");
    }
}
// Parms are the same. This function just returns list in biggest to smallest order.
void insertion_sort_max(int numbers[], int n){
    int loop_count, array_count, move_count, index, print_count;
    // for loop used to cycle thru list n times
    for(loop_count = 0; loop_count < n - 1; loop_count++){
        index = loop_count + 1;
        // bubble sorts thru array until index is reached 
        while(index > 0 && numbers[index] > numbers[index - 1]){
            int temp = numbers[index];
            numbers[index] = numbers[index - 1];
            numbers[index - 1] = temp;
            index--;
        }
        // print array at end of each loop to check insertion is working in correct order.
        for(print_count = 0; print_count < n; print_count++){
            printf("%d ", numbers[print_count]);
        }
        printf("\n");
    }
}
