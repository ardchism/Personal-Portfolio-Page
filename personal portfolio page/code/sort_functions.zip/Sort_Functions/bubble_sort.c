/* 
 * File:   bubble_sort.c
 * Author: Adam Chisholm
 * Use: Sort array of ints using a modified bubble sort.
 * Created on 2/10/2016
 */

#include <stdio.h>
#include <stdlib.h>

// First parm is an int array, while the second is the number of ints in the array
void bubble_sort_min(int numbers[], int n){
    int loop_count, number_count, flag = 0;
    
    // for loop used to cycle thru list n times
    for(loop_count = 0; loop_count < n; loop_count++){
        
        // for loop used to move thru each 2 number pair
        for(number_count = 0; number_count < n-1; number_count++){
           
            // check which number is greater and switch if needed
            if(numbers[number_count] > numbers[number_count + 1]){
                int temp = numbers[number_count + 1];
                numbers[number_count + 1] = numbers[number_count];
                numbers[number_count] = temp;
                
                // add to flag if a switch was made
                ++flag;
            }
        }
       
        // if flag = 0 then no switch was made and list is in order
        if(flag == 0){
            printf("loop was in order after %d  full loops\n", loop_count);
            break;
        }
        else{
            flag = 0;
        }
    }
}

// Parms are the same. This function just returns list in biggest to smallest order.
void bubble_sort_max(int numbers[], int n){
    int loop_count, number_count, flag = 0;
    
    // for loop used to cycle thru list n times
    for(loop_count = 0; loop_count < n; loop_count++){
       
        // for loop used to move thru each 2 number pair
        for(number_count = 0; number_count < n-1; number_count++){
            
            // check which number is smaller and switch if needed
            if(numbers[number_count] < numbers[number_count + 1]){
                int temp = numbers[number_count + 1];
                numbers[number_count + 1] = numbers[number_count];
                numbers[number_count] = temp;
                
                // add to flag if a switch was made
                ++flag;
            }
        }
        
        // if flag = 0 then no switch was made and list is in order
        if(flag == 0){
            printf("loop was in order after %d  full loops\n", loop_count);
            break;
        }
        else{
            flag = 0;
        }
    }
}
